﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class Registro : Form
    {

        private MySqlConnection connection;
        private string connectionString = "Server=localhost;Database=usuarios;User ID=Usuario_MySql;Password=Clave_usuario;";

        public Registro()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (RegistrarNuevoUsuario(username, password))
            {
                MessageBox.Show("Registro exitoso. Ahora puedes iniciar sesión con tus nuevas credenciales.");
               
                this.Close(); // Cerrar el formulario de registro después del éxito.
 }
            else
            {
                MessageBox.Show("Error en el registro. Asegúrate de que el nombre de usuario no exista.");
            }
        }

        private bool RegistrarNuevoUsuario(string username, string password)
        {
            try
            {
                // Abre la conexión a la base de datos.
                connection.Open();
                // Verifica si el nombre de usuario ya existe en la base de datos.
                string verificarExistencia = "SELECT COUNT(*) FROM user WHERE usuario = @username";
                MySqlCommand cmdVerificar = new MySqlCommand(verificarExistencia,connection);
                cmdVerificar.Parameters.AddWithValue("@username", username);
                int count = Convert.ToInt32(cmdVerificar.ExecuteScalar());
                // Si el nombre de usuario ya existe, retorna falso (no se puede registrar).
                if (count > 0)
                {
                    // El nombre de usuario ya existe.
                    return false;
                }
                // Si el nombre de usuario no existe, procede a insertar un nuevo usuario.
                 string query = "INSERT INTO user (usuario, password) VALUES (@username, @password)";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                // Ejecuta la consulta para insertar el nuevo usuario.
                cmd.ExecuteNonQuery();
               
            // Retorna verdadero para indicar que el registro fue exitoso.
                return true;
            }
            catch (Exception ex)
            {
                // Muestra un mensaje de error en caso de excepción.
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
            finally
            {
                // Cierra la conexión a la base de datos después de usarla.
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

        }
    }
}

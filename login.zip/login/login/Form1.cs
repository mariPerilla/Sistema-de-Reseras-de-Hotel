using MySql.Data.MySqlClient;
using System.Data;

namespace login
{
    public partial class Form1 : Form
    {
        private MySqlConnection connection;
        private string connectionString = "Server=localhost;Database=usuarios;User ID=Usuario_MySql;Password=Clave_usuario;";

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            // Reemplaza la siguiente condici�n con tu l�gica de autenticaci�n real
            if (IsValidUser(username, password))
            {
                MessageBox.Show("Inicio de sesi�n exitoso");
                // Agrega c�digo para navegar al siguiente formulario o realizar otras acciones despu�s del inicio de sesi�n exitoso
                // Abre el nuevo formulario despu�s de un inicio de sesi�n exitoso
                NuevoFormulario nuevoFormulario = new NuevoFormulario();
                nuevoFormulario.Show();
                // Puedes ocultar el formulario actual si es necesario
                this.Hide();
            }
            else
            {
                MessageBox.Show("Nombre de usuario o contrase�a no v�lidos. Por favor, int�ntalo de nuevo.");
            }
        }
        private bool IsValidUser(string username, string password)
        {
            try
            {
                // Abre la conexi�n a la base de datos.
                connection.Open();
                // Consulta SQL para recuperar las credenciales.
                string query = "SELECT * FROM user WHERE usuario = @username AND password = @password; ";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                // Agrega par�metros a la consulta para evitar la inyecci�n de SQL.
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                // Ejecuta la consulta y verifica si hay filas en el resultado.
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    return reader.HasRows;
                }
            }
            catch (Exception ex)
            {
                // Muestra un mensaje de error en caso de excepci�n.
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
            finally
            {
                // Cierra la conexi�n a la base de datos despu�s de usarla.
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Abrir el formulario de registro
            Registro Registro = new Registro();
            Registro.ShowDialog();

        }
    }
}
